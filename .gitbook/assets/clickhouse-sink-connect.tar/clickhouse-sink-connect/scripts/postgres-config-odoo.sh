# Postgres config
SOURCE_CONNECTOR_NAME="postgres-source-connector"
POSTGRES_HOST="192.168.88.129"
POSTGRES_PORT=5432
POSTGRES_USER="odoo"
POSTGRES_PASSWORD="root"
DATABASE_DBNAME="odoo"
TOPIC_PREFIX="postgres"
TABLE_INCLUDE_LIST="public.hr_expense_sheet,public.ir_attachment"
