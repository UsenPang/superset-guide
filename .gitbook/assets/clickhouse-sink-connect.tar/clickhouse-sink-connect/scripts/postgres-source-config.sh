# Postgres config
SOURCE_CONNECTOR_NAME="postgres-source-connector"
POSTGRES_HOST="192.168.1.86"
POSTGRES_PORT=5432
POSTGRES_USER="odoo"
POSTGRES_PASSWORD="tongxin"
DATABASE_DBNAME="roniki_acc"
TOPIC_PREFIX="postgres"
#TABLE_INCLUDE_LIST="public.hr_expense_sheet,public.ir_attachment"
