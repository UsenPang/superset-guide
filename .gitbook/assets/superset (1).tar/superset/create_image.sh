#!/bin/bash
docker build -t "tongxin/superset-clickhouse:4.0.0" .
